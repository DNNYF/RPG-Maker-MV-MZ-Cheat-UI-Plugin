# Installation Instructions for RPG Maker MZ

## Step 1: Backup
Backup your game's `js/main.js` file before proceeding.

## Step 2: Copy Files
1. Copy all folders from this package to your game directory
2. The `js/main.js` file will be overwritten
3. The `cheat` folder will be created
4. The `cheat-settings` folder will be created (for storing settings)

## Step 3: Launch Game
1. Run your game
2. Press `Ctrl + C` to open the cheat window
3. Enjoy the enhanced cheat features!

## File Structure After Installation
```
{game_directory}/
├── js/
│   └── main.js (overwritten)
├── cheat/
│   ├── components/
│   ├── init/
│   ├── js/
│   ├── libs/
│   ├── panels/
│   ├── settings/
│   └── ...
├── cheat-settings/ (created at runtime)
└── cheat-version-description.json
```

## Features
- Enhanced translation with multiple providers
- Bookmark frequently used items and variables
- Lock item values to prevent changes
- Smart scroll to last modified item
- Give all items per category

See FEATURES.md for detailed documentation.
